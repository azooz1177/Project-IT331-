@extends('layot')



@section('title')
    Create
@endsection



@section('content')

    <form method="POST" action="/project" class="login-box">
        @csrf

        <label style="color: black">Name Of Project :
            <input type="text" name="name" class="textbox" placeholder="Project Name">
        </label>

        <label style="color: black">Description :
            <textarea name="description" class="textbox" placeholder="Project description"></textarea>
        </label>

        <input type="submit" name="AddPro" value="Add Project" class="btn">
    </form>

@endsection

