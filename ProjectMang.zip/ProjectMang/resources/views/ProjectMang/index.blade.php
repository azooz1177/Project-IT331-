@extends('layot')



@section('title')
    Welcome
@endsection



@section('content')

    @foreach($project as $projects)
        <h1><a href="/project/{{$projects->id}}">{{ $projects->name }}</a>
            <a href="/deleteProject/{{$projects->id}}"><button class="bt2">Delete</button></a>
            <a href="/updateProject/{{$projects->id}}"><button class="bt2">update</button></a></li>
        </h1>

    @endforeach

@endsection

