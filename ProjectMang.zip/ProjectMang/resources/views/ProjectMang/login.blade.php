@extends('layot')



@section('title')
    Log In
@endsection



@section('content')

   <form method="post" action="/logInme" class="login-box">
       @csrf
        <input type="text" name="name" placeholder="username" class="textbox">
       <br>
       <input type="password" name="password" placeholder="Password" class="textbox">
        <br>
       <input type="submit" name="submet" value="Login" class="btn">
   </form>

@endsection

