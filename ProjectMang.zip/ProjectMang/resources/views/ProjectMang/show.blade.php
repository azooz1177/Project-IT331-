@extends('layot')



@section('title')
    {{$project->name}}
@endsection



@section('content')

    <h1>{{$project->name}}</h1>
    <h3>{{$project->description}}</h3>

    <hr>


<ul style="list-style-type:none">
    @foreach($project->Tasks as $Tasks)


            <li>{{$Tasks->name}} <a href="/deleteTask/{{$Tasks->id}}"><button class="bt2">Delete</button></a>
                <a href="/updateTask/{{$Tasks->id}}"><button class="bt2">update</button></a></li>

    @endforeach
</ul>

<hr>
    <div align="center">
        <br><br>
    <form class="form" method="POST" action="/project/{{$project->id}}/task" class="login-box">

    @csrf
        <input type="text" name="name" placeholder="Enter Task" class="textbox1">
        <input type="submit" name="AddTask" value="Add Task"class="btn1" >
    </form>
    </div>
@endsection

