<?php $__env->startSection('title'); ?>
    update
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
<div align="center">
    <br><br>
    <form method="" action="/afterupdateProject/<?php echo e($id); ?>" class="login-bo" >
        <?php echo csrf_field(); ?>
        <input name="name" type="text" class="textbox1" placeholder="New Name">
        <input type="submit" class="btn1" value="UpDate">
    </form>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>